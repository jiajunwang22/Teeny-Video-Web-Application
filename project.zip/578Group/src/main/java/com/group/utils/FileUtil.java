package com.group.utils;

import java.util.UUID;

public class FileUtil {

	public static String rename(String originName) {
		String suffix = originName.substring(originName.lastIndexOf("."));
		String newName = UUID.randomUUID().toString() + suffix;
		return newName;
	}
}
