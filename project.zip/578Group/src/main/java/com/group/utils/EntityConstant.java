package com.group.utils;

import com.group.entity.Admin;
import com.group.entity.User;
import com.group.entity.Video;
import com.group.entity.base.constant.CityConstant;
import com.group.entity.base.constant.StateConstant;
import com.group.entity.base.constant.UserTypeConstant;

public class EntityConstant {

	public static final Class ADMIN = Admin.class;
	public static final Class USER = User.class;
	public static final Class USER_TYPE_CONSTANT = UserTypeConstant.class;
	public static final Class VIDEO = Video.class;
	public static final Class CITY_CONSTANT = CityConstant.class;
	public static final Class STATE_CONSTANT = StateConstant.class;
	
}
