package com.group.utils;

public class EntityClassParser {
	
	public static Class string2Class(String classStr) {
		classStr = classStr.toLowerCase();
		switch (classStr) {
		case "admin":
			return EntityConstant.ADMIN;
		case "user":
			return EntityConstant.USER;
		case "usertypeconstant":
			return EntityConstant.USER_TYPE_CONSTANT;
		case "video":
			return EntityConstant.VIDEO;
		case "cityconstant":
			return EntityConstant.CITY_CONSTANT;
		case "stateconstant":
			return EntityConstant.STATE_CONSTANT;
		default:
			return null;
		}
	}

}
