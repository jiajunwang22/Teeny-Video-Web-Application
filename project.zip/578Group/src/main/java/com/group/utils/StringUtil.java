package com.group.utils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;

import com.group.entity.Video;

public class StringUtil {

	public static boolean isEmpty(String string) {
		boolean b = false;
		string = string.trim();
		if("".equals(string) || string == null) {
			b = true;
		}
		
		return b;
	}
	
}
