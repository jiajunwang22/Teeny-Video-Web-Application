package com.group.controller.base;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.group.service.base.IBaseGenericService;
import com.group.utils.EntityClassParser;
import com.group.utils.JsonUtil;

@Controller
public class BaseController<T> {

	private T entity;

	private Class entityClass;

	@Autowired
	private IBaseGenericService<T> service;

	@ModelAttribute
	public void setEntityClass(String bizModule) throws InstantiationException, IllegalAccessException {
		if (bizModule != null) {
		this.entityClass = EntityClassParser.string2Class(bizModule);
		this.entity = (T) entityClass.newInstance();
		}
	}

	@RequestMapping("/save")
	@ResponseBody
	public void save(String entityJsonString, MultipartFile file, HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException {
		T entity = (T) JsonUtil.string2obj(entityJsonString, entityClass);
		service.save(entity, file, request);
	}

	@RequestMapping("/list")
	@ResponseBody
	public String list(String filterString, String order) throws JsonParseException, JsonMappingException, IOException {
		Map filterMap = (Map) JsonUtil.string2obj(filterString, Map.class);
		return JsonUtil.obj2json(service.get(filterMap, entityClass, order));
	}

	@RequestMapping("/get")
	@ResponseBody
	public String get(String id) throws JsonParseException, JsonMappingException, IOException {
		return JsonUtil.obj2json(service.load(id, entityClass));
	}
	
	@RequestMapping("/delete")
	@ResponseBody
	public void delete(String entityJsonString, HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException {
		T entity = (T) JsonUtil.string2obj(entityJsonString, entityClass);
		service.delete(entity, request);
	}

	@RequestMapping("/update")
	@ResponseBody
	public void update(String entityJsonString) throws JsonParseException, JsonMappingException, IOException {
		T entity = (T) JsonUtil.string2obj(entityJsonString, entityClass);
		service.update(entity);
	}

	@RequestMapping("/merge")
	@ResponseBody
	public void merge(String entityJsonString) throws JsonParseException, JsonMappingException, IOException {
		T entity = (T) JsonUtil.string2obj(entityJsonString, entityClass);
		service.merge(entity);
	}
	
	@RequestMapping("/index")
	public String index() {
		return "home";
	}
	
	@RequestMapping("/user")
	public String user() {
		return "user";
	}
	
	@RequestMapping("/admin")
	public String admin() {
		return "admin";
	}
	
	@RequestMapping("/administrator")
	public String administrator() {
		return "administrator";
	}
}
