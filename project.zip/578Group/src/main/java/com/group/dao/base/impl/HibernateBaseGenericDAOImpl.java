package com.group.dao.base.impl;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.group.dao.base.IBaseGenericDAO;
import com.group.entity.Video;
import com.group.entity.base.Page;
import com.group.utils.StringUtil;

@Repository
public class HibernateBaseGenericDAOImpl<T> extends HibernateDaoSupport implements IBaseGenericDAO<T> {

	@Resource
	public void setSessionFacotry(SessionFactory sessionFacotry) {
		super.setSessionFactory(sessionFacotry);
	}

	private static Log logger = LogFactory.getLog(HibernateBaseGenericDAOImpl.class);

	private Class<T> entityClass;

	public HibernateBaseGenericDAOImpl() {
		this.entityClass = null;
		Class c = getClass();
		Type t = c.getGenericSuperclass();
		if (t instanceof ParameterizedType) {
			Type[] p = ((ParameterizedType) t).getActualTypeArguments();
			this.entityClass = (Class<T>) p[0];
		}
	}

	public List get(Map<String, String> filter, Class entityClass, String order) {
		Page page = null;
		List list = new ArrayList();
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();
		try {
			Criteria query = session.createCriteria(entityClass);
			if (filter != null && !filter.isEmpty()) {
				for (Iterator i = filter.keySet().iterator(); i.hasNext();) {
					String paramName = (String) i.next();
					if (paramName.equalsIgnoreCase("id") && !StringUtil.isEmpty(filter.get("id"))) {
						query.add(Restrictions.eq("id", filter.get("id")));
					} else if ((paramName.equalsIgnoreCase("caption")) && !StringUtil.isEmpty(filter.get("caption"))) {
						query.add(Restrictions.like(paramName, "%" + filter.get(paramName) + "%"));
					}
					else if (paramName.equalsIgnoreCase("orderBy") && !StringUtil.isEmpty(filter.get("orderBy"))) {
						if (order.equalsIgnoreCase("asc")) {
							query.addOrder(Order.asc(filter.get(paramName)));
						} else if (order.equalsIgnoreCase("desc")) {
							query.addOrder(Order.desc(filter.get(paramName)));
						}
					} else if (paramName.equalsIgnoreCase("pageNo") && !StringUtil.isEmpty(filter.get("pageNo"))
							&& (Integer.parseInt((String) filter.get("pageNo")) > 0)) {
						int pageNo = Integer.parseInt((String) filter.get("pageNo"));
						int pageSize = Integer.parseInt((String) filter.get("pageSize"));
						query.setFirstResult(pageSize * (pageNo - 1));
						query.setMaxResults(pageSize);
					} else if (!StringUtil.isEmpty(filter.get(paramName)) && !paramName.equalsIgnoreCase("id")
							&& !paramName.equalsIgnoreCase("caption") && !paramName.equalsIgnoreCase("orderBy")
							&& !paramName.equalsIgnoreCase("pageNo") && !paramName.equalsIgnoreCase("pageSize")) {
						query.add(Restrictions.eq(paramName, filter.get(paramName)));
					}

				}
			}
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			list = query.list();
			tran.commit();
		} catch (Exception e) {
			tran.rollback();
			e.printStackTrace();
		} finally {
			session.flush();
			session.close();
		}
		return list;
	}

	public void delete(T entity) {
		try {
			getHibernateTemplate().delete(entity);
		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void save(T entity) {
		try {
			getHibernateTemplate().save(entity);
		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void saveOrUpdate(T entity) {
		try {
			getHibernateTemplate().saveOrUpdate(entity);
		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void update(T entity) {
		try {
			getHibernateTemplate().update(entity);
		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void merge(T entity) {

		String id = "";
		String table = entity.getClass().getSimpleName();
		String hql = "update " + table + " " + "set ";
		Field[] fields = entity.getClass().getDeclaredFields();
		Iterator iterator = Arrays.asList(fields).iterator();
		while (iterator.hasNext()) {
			Field f = (Field) iterator.next();
			f.setAccessible(true);
			try {
				if (f.getName().equals("id")) {
					id = (String) f.get(entity);
				} else if (f.get(entity) != null) {
					hql +=  f.getName() + "=" + f.get(entity) + ", ";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		hql = hql.substring(0, hql.lastIndexOf(","));
		hql += " where id=" + "'" + id + "'";
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction ts = session.beginTransaction();
		Query query = session.createQuery(hql);
		query.executeUpdate();
		ts.commit();
	}

	public T load(String id, Class entityClass) {
		T t = null;
		try {
			t = (T) getHibernateTemplate().get(entityClass, id);
		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
		return t;
	}
}
