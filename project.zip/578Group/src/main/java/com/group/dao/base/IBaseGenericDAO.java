package com.group.dao.base;

import java.io.File;
import java.util.List;
import java.util.Map;

public abstract interface IBaseGenericDAO<T> {  

    public abstract List get(Map<String, String> filter, Class entityClass, String order);
  
    public abstract void update(T entity);  
  
    public abstract void save(T entity);  

    public abstract void delete(T entity); 
    
    public abstract T load(String id, Class classEntity);
      
    public abstract void merge(T entity);
}  