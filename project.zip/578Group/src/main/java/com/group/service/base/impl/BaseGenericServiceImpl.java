package com.group.service.base.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.group.dao.base.IBaseGenericDAO;
import com.group.entity.Video;
import com.group.service.base.IBaseGenericService;
import com.group.utils.FileUtil;

@Service
public class BaseGenericServiceImpl<T> implements IBaseGenericService<T> {  
		
    @Autowired  
    private IBaseGenericDAO<T> dao;  
      
    public void delete(T entity, HttpServletRequest request) {  
        if (entity.getClass().getSimpleName().equalsIgnoreCase("video")) {
            String path = request.getSession().getServletContext().getRealPath("upload");
            Video video = (Video) entity;
            if(video.getFileName() != null) {
            	 File targetFile = new File(path, video.getFileName()); 
             	try {
             		targetFile.delete();
             	} catch (Exception e) {
             		e.printStackTrace();
     			}
            }
           

            dao.delete(entity);
        }
    }  

    public void save(T entity, MultipartFile file, HttpServletRequest request) { 
    	String fileName = "";
        if(file != null) {
            String path = request.getSession().getServletContext().getRealPath("upload"); 
            fileName = FileUtil.rename(file.getOriginalFilename());
            System.out.println(path);  
            File targetFile = new File(path, fileName); 
            if(!targetFile.exists()){  
                targetFile.mkdirs();  
            } 
            try {  
                file.transferTo(targetFile);  
            } catch (Exception e) {  
                e.printStackTrace();  
            }
           String filePath = "upload/" + fileName;
           Video video = (Video) entity;
           video.setFilePath(filePath);
           video.setFileName(fileName);
           video.setCreateOn(new Date());
           video.setFlag("0");
        }
        dao.save(entity);
 
    }  

    public void update(T entity) {  
        dao.update(entity);  
    }

	public List get(Map<String, String> filter, Class entityClass, String order) {
		return dao.get(filter, entityClass, order);
	}  
  
	public T load(String id, Class entityClass) {
		return dao.load(id, entityClass);
	}
	
	public void merge(T entity) {
		dao.merge(entity);
	}
}  