package com.group.service.base;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

public interface IBaseGenericService<T> {  
	  
    public abstract List get(Map<String, String> filter, Class entityClass, String order);

    public abstract void update(T entity);  
  
    public abstract void save(T entity, MultipartFile file, HttpServletRequest request);  

    public abstract void delete(T entity, HttpServletRequest request);  
    
    public abstract T load(String id, Class entityClass);
    
    public abstract void merge(T entity);
}  