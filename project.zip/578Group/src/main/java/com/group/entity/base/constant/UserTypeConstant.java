package com.group.entity.base.constant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.GenericGenerator;

import com.group.entity.base.BaseEntity;

@Entity
@Table(name="UserTypeConstant")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)

public class UserTypeConstant extends BaseEntity {

	@Id
	@GenericGenerator(name="systemUUID",strategy="uuid")  
	@GeneratedValue(generator="systemUUID")  
	@Column(name="id")
	private String id;
		
	@Column(name="userTypeName")
	private String userTypeName;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	
	public String getUserTypeName() {
		return userTypeName;
	}
	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}
	
	
}
