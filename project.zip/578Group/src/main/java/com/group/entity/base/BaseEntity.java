package com.group.entity.base;

import java.io.Serializable;

public class BaseEntity implements Serializable {

}
