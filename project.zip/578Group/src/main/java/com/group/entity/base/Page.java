package com.group.entity.base;

import java.util.List;

public class Page<E> {

	private List<E> list;

	private int pageNo;
	
	public Page (int pageNo, List list) {
		this.pageNo = pageNo;
		this.list = list;
	}

	public int countOffset(int currentPage, int pageSize) {
		int offset = pageSize * (currentPage - 1);
		return offset;
	}

	public int getTopPageNo() {
		return 1;
	}

	public int getPreviousPageNo() {
		if (pageNo <= 1) {
			return 1;
		}
		return pageNo - 1;
	}

	public List<E> getList() {
		return list;
	}

	public void setList(List<E> list) {
		this.list = list;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}


	
}
