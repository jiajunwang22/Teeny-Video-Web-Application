var curUser= "";
var curId = "";
var targetUser = "";
var targetId = "";

function getScope(selector) {
	return $(selector).scope();
}

function applyF2(){
	scope = $('div[ng-controller="video_list"]').scope();
}



function myPopup(obj) {
	var filePath = $(obj).attr("data-filePath");
	var userId = $(obj).attr("data-userId");
	sessionStorage.setItem("targetId", userId);
	var caption = $(obj).attr("data-caption");
	var remark = $(obj).attr("data-remark");
	$("#myPopup").attr("href", filePath);
	$("#myPopup").attr("title", "<a href='user'>" + caption + "</a >");
	$("#myPopup").click();
}
