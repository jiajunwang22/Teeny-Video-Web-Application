var pageNo;
var size;
var scope;



function store_userId(){
	var filter = {
		 "userName": sessionStorage.getItem("currentUser"),
};
console.log($("#signup-email").val());
var param = {
		"bizModule" : "user",
		"filterString":angular.toJson({"userName": sessionStorage.getItem("currentUser")})
	};

$.ajax({
	url : "list",
	dataType : "json",
	data : {
		"bizModule" : "user",
		"filterString":angular.toJson({"userName": sessionStorage.getItem("currentUser")})},
	method : 'POST',
	success : function(data) {
			var strdata2 = JSON.parse(data);
			console.log(strdata2);
			var tempid = strdata2[0].id;
			sessionStorage.setItem("currentId",tempid);		
	}
});
}

function relocate() {
	var str = $("#radio_button").html();
	$("#radio_location").html(str);
}

function login_target(){
	 var tempid = sessionStorage.getItem("currentId");
	 var tempuser = sessionStorage.getItem("currentUser");
	 sessionStorage.setItem("targetId", tempid);
	 sessionStorage.setItem("targetUser", tempuser);
	console.log(tempid+" "+sessionStorage.getItem("targetId"));
	}

function user_name() {
	$("#after_log").hide();
	if (sessionStorage.getItem("currentUser")) {
		$("#prelog").hide();
		$("#after_log").show();
		$("#user_name").html(sessionStorage.getItem("currentUser"));	
	}
}

var mainapp = angular.module('indexApp', []);
mainapp.controller('signCtrl', function($scope) {
	        $("#sign_up_submit").attr("disabled",true);
			$scope.param = {};
			$scope.param.bizModule = "user";
			$scope.param.entityJsonString = "";
			$scope.param.entityJson = {};
			$scope.param.filterString = "";
			$scope.result = {};
			$scope.url = "save";
			$scope.signup = function() {
				$scope.param.entityJson.userName = $("#signup-email").val();
				$scope.param.entityJson.password = $("#signup-password").val();
				$scope.param.entityJson.userTypeId = $("input[name='optradio']:checked").val();
				$scope.param.entityJson.stateId = "0";
				$scope.param.entityJson.cityId = "0";
				$scope.param.entityJsonString = angular.toJson($scope.param.entityJson);
				$.ajax({
					url : $scope.url,
					dataType : "json",
					data : $scope.param,
					method : 'POST',
					success : function(data) {
						store_userId();
					},
					error: function(){
						store_userId();
					}
				});
				sessionStorage.setItem("currentUser", $scope.param.entityJson.userName);
				$('.cd-user-modal').removeClass('is-visible');
				user_name();
			}
		});

function getButton() {
	var scope = $('div [ng-controller="signCtrl"]').scope();
	var param = {
		"bizModule" : "userTypeConstant"
	};
	$.ajax({
		url : "list",
		dataType : "json",
		data : param,
		method : 'POST',
		success : function(data) {
			scope.$apply(function() {
				var strdata = JSON.parse(data);
				scope.radio_data = strdata;
			});
		}
	});
}

$(function(){
	$("#signup-email").blur(function(){
		var filter = {
			      "userName": $("#signup-email").val(),
	};
	console.log($("#signup-email").val());
	var param = {
			"bizModule" : "user",
			"filterString":angular.toJson({"userName": $("#signup-email").val()})
		};

	$.ajax({
		url : "list",
		dataType : "json",
		data : {
			"bizModule" : "user",
			"filterString":angular.toJson({"userName": $("#signup-email").val()})},
		method : 'POST',
		success : function(data) {
				var strdata2 = JSON.parse(data);
				console.log(strdata2);
				if(strdata2.length>0){
					
					$("#user_exist").css("visibility", "visible");
					
				} else {
					
					$("#user_exist").css("visibility", "hidden");
					 $("#sign_up_submit").attr("disabled",false);
						
				}		
			
		}
	});
		
	});
});


function check_username(){

			$scope.user_name = "";
			$scope.param = {};
			$scope.param.bizModule = "user";
			$scope.param.entityJsonString = "";
			$scope.param.filterString = "";
			$scope.result = {};
			$scope.url = "list";
			$scope.param.filter = {};
			$scope.param.filter.userName = $("#signup-email").val();
			console.log($("#signup-email").val());
			$scope.param.filter.password = "";
			$scope.login = function() {
				$scope.param.filterString = angular.toJson($scope.param.filter);
				$.ajax({
					url : $scope.url,
					dataType : "json",
					data : $scope.param,
					method : 'POST',
					success : function(data) {
						$scope.result = JSON.parse(data);
						if ($scope.result.length > 0) {
							$("#user_exist").css("visibility", "visible");
							
						} else {
							 $("#sign_up_submit").attr("disabled",false);
						}
					},
				error :function() {
					console.log($scope.param);
				}
			});
		}
		
}

// video list
mainapp.controller('video_list', function($http, $scope) {
	$scope.param = {};
	pageNo=1;
	$scope.url = "list";
	$scope.result = {};
	$scope.param.bizModule = "video";
	$scope.param.order = "desc";
	$scope.param.filter = {};
	$scope.param.filter.caption ="";
	$scope.param.filter.flag = "1";
	$scope.param.filter.orderBy = "createOn";
	$scope.param.filter.pageNo = "1";
	$scope.param.filter.pageSize = 12+"" ;
	$scope.param.filterString = "";
	$scope.param.entityJson = {};
	$scope.param.entityJsonString = "";
	$scope.load_videos = function() {
		$scope.param.filterString = angular.toJson($scope.param.filter);
		$.ajax({
			url : $scope.url,
			dataType : "json",
			data : $scope.param,
			method : 'POST',
			success : function(data) {
				getScope('div[ng-controller="video_list"]').$apply(function() {
					$scope.videos = $.parseJSON(data);
					console.log($scope.videos.length);
				});
			}
		});
	};
});

//var winH = $(window).height();
//$(window).scroll(function () {  
//    var pageH = $(document.body).height();  
//    var scrollT = $(window).scrollTop();   
//    var aa = (pageH - winH - scrollT) / winH;  
//    if (aa < 100) {
//    	
//});  

$(window).scroll(function(){
    var winH = $(window).height(),
        domH = $(document).height(),
        scrollTop = $(document).scrollTop();
    //下面的1是距离底部只有1px的意思，可根据个人需要修改
    if(domH - winH - scrollTop < 1) {
    	var s = getScope('div[ng-controller="video_list"]')
    	s.$apply(function() {
    		s.param.filter.pageSize = (parseInt(s.param.filter.pageSize) + 12) + "" ;
			s.load_videos();	
		});
    }             
             
});


function search() {
	var query = document.getElementById("input_box").value;
	var scope = $('form [ng-controller="video_list"]').scope();
	console.log(query);
	console.log(scope);
	$.ajax({
        url: "list",
        data: {"bizeModule":"video", "filterString":angular.toJson({"caption":query,"orderBy":"createOn"}),"order":"asc"},
        dataType : "json",
        method:'POST',
        success: function(data) {
        	scope.$apply(function() {
				scope.videos = angular.toJson(data);
				});
        	}
		});	
	}
