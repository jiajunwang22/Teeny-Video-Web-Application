

var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
	$scope.param = {} ;
//	$scope.param.filter= {};
//	$scope.param.filter.id = $;
//	$scope.param.filter.pageNo= '';
//	$scope.param.filter.pageSize='';
//	$scope.param.filter.caption='';
//	$scope.param.filter.orderBy='';
//	$scope.param.filter.desc ='';
//	$scope.param.filter.asc ='';
	
	
	
	
//	$scope.param.save
	$scope.param.bizModule = "admin";

	$scope.param.entityJsonString = "";
	$scope.param.filterString = "";
	
	$scope.url = "list";
	
	$scope.result = {}; 
	
	$scope.login = function() {
		$scope.param.filter = {};
		$scope.param.filter.adminName = $("#username").val();
		$scope.param.filter.password = $("#password").val();
		console.log($scope.param);
//		$scope.param.entityJsonString = angular.toJson($scope.param.entityJson);
		$scope.param.filterString = angular.toJson($scope.param.filter);
		
 		$.ajax({
			url: $scope.url,
			dataType:"json",
			data: $scope.param,
			method:'POST',
			success: function(data) {
				$scope.result = JSON.parse(data);
				if ($scope.result.length > 0) {
					window.location.href = "administrator";
				}
			}
 		   
		});
	}
});