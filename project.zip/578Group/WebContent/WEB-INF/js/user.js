//var time = new Date().getTime();
//alert(time);
//var date = new Date(time);
//alert(data);
//alert(date.toString());

var userApp = angular.module('userApp', []);
userApp.controller('userCtrl', function($scope) {
	
	$scope.flag;
	$scope.param = {} ;
	$scope.param.id = sessionStorage.getItem("targetId");
	$scope.param.bizModule = "user";
	$scope.result = {}; 
	$scope.resultState = {}; 
	$scope.resultCity = {};
	
	$scope.param.filter = {};
	$scope.param.filterString = "";
	
	$scope.entityJson = {}
	$scope.entityJsonString = "";
	
	var tarId1 = sessionStorage.getItem("targetId");
	var curId1 = sessionStorage.getItem("currentId");
	if(tarId1 != curId1){
		$scope.flag = "1";
		
	 }
	
	$scope.load = function() {
		
		$.ajax({
			url: "get",
			data: $scope.param,
	        dataType:"json",
			method:'POST',
			success: function(data) {
				getScope("body[ng-controller='userCtrl']").$apply(function() {
					$scope.entityJson = $.parseJSON(data);				
				})
				$scope.param = {};
				$scope.param.bizModule = "stateConstant";
			    $scope.param.order = "asc";
			    $scope.param.filter = {};
				$scope.param.filter.orderBy = "stateName";
				$scope.param.filterString = angular.toJson($scope.param.filter);
				
				$.ajax({
					url: "list",
					data: $scope.param,
			        dataType:"json",
					method:'POST',
					success:function(data) {
						getScope("body[ng-controller='userCtrl']").$apply(function() {
							$scope.resultState = $.parseJSON(data);
							$scope.param = {};
							$scope.param.bizModule = "cityConstant";
						    $scope.param.order = "asc";	
						    $scope.param.filter = {};
							$scope.param.filter.orderBy = "cityName";
							var stateCode = "";
							for (x in $scope.resultState) {
								if ($scope.resultState[x].id == $scope.entityJson.stateId) {
									stateCode = $scope.resultState[x].stateCode;
								}
							}	
							$scope.param.filter.stateCode = stateCode;
							$scope.param.filterString = angular.toJson($scope.param.filter);
							
							$.ajax({
								url: "list",
								data: $scope.param,
						        dataType:"json",
								method:'POST',
								success:function(data) {
									getScope("body[ng-controller='userCtrl']").$apply(function() {
										$scope.resultCity = $.parseJSON(data);
										

										checkUser();
									});
								}
							});					
						});
					}
				});
			}
		});
	};
	
	$scope.update = function() {
    	$.ajax({
            url: "update",
            data: {"bizModule":"user", "entityJsonString":angular.toJson($scope.entityJson)},
            method:'POST',
            success: function() {
            	window.location.reload();
            }
          });	
	};
});

function submitForm() {
	var caption = $("#caption").val();
	var userId = $("#userId").val();
	$("#entityJsonString").val(angular.toJson({"userId": userId, "caption":caption}));
	document.getElementById("uploadForm").submit(setTimeout("window.location.href='user'",1000));

}

function deleteVideo(obj) {
	var id = $(obj).attr("data-id");
	var fileName = $(obj).attr("data-fileName");
	var entityJsonString = angular.toJson({"id":id, "fileName": fileName});
	var param = {"bizModule":"video", entityJsonString}
	$.ajax({
        url: "delete",
        data:param,
        method:'POST',
        success: function() {
        	$("#" + id).remove();
        }
      });
}

function checkUser(){
	 var tarId = sessionStorage.getItem("targetId");
	 var curId = sessionStorage.getItem("currentId");
	 if(tarId != curId) {
	  $("button").hide();
	  $("input, select").attr("disabled",true);
	  $("#upload_file").css("display", "none");
	  $(".alert").css("display", "none");
	 }
	}


function chooseState() {
	var stateCode = $("#" + $("#stateCodeSelect").val()).attr("data-stateCode");
	console.log(stateCode);
	$.ajax({
		url: "list",
		data: {"bizModule":"cityConstant","order":"asc","filterString":JSON.stringify({"stateCode":stateCode,"orderBy":"cityName"})},
        dataType:"json",
		method:'POST',
		success:function(data) {
			var scope = getScope("body[ng-controller='userCtrl']")
			scope.$apply(function() {
				scope.resultCity = $.parseJSON(data);
			});
		}
     });
	
}