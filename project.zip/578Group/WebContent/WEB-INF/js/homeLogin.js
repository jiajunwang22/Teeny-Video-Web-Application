function user_name() {
	$("#after_log").hide();
	if (sessionStorage.getItem("currentUser")) {
		$("#prelog").hide();
		$("#after_log").show();
		$("#user_name").html(sessionStorage.getItem("currentUser"));	
	}
}

mainapp.controller('logCtrl', function($scope) {
	$scope.user_name = "";
	$scope.param = {};
	$scope.param.bizModule = "user";
	$scope.param.entityJsonString = "";
	$scope.param.filterString = "";
	$scope.result = {};
	$scope.url = "list";
	$scope.param.filter = {};
	$scope.param.filter.userName = "";
	$scope.param.filter.password = "";
	
	$scope.login = function() {
		console.log($scope.param.filter.userName);
		$scope.param.filterString = angular.toJson($scope.param.filter);
		$.ajax({
			url : $scope.url,
			dataType : "json",
			data : $scope.param,
			method : 'POST',
			success : function(data) {
				$scope.result = JSON.parse(data);
				if ($scope.result.length > 0) {
					sessionStorage.setItem("currentId", $scope.result[0].id);
					sessionStorage.setItem("currentUser", $scope.result[0].userName);
//					alert(sessionStorage.getItem("currentId"));
					$('.cd-user-modal').removeClass('is-visible');
					$("#prelog").hide();
					user_name();				
				} else {
//					alert(1);
					$("#prompt").css("visibility", "visible");
				}
			}
		});
	}
});