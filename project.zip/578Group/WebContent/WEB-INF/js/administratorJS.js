var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
    $scope.url = "list";
    $scope.result = {};
    $scope.param = {};
    $scope.param.bizModule = "video";
    $scope.param.order = "desc";
    $scope.param.filter = {};
    $scope.param.filter.flag = "0";
    $scope.param.filter.orderBy = "createOn";
    $scope.param.filterString = "";
    $scope.param.entityJson = {};
    $scope.param.entityJsonString = "";
    $scope.load = function() {
        $scope.param.filterString = angular.toJson($scope.param.filter);
        
        
        $.ajax({
          url: $scope.url,
          dataType:"json",
          data: $scope.param,
          method:'POST',
          success: function(data) {
          getScope('body[ng-controller="myCtrl"]').$apply(function() {
        	  $scope.result = $.parseJSON(data);
        	  
        	  if( $scope.result.length==0){
        		 
        		 $("#no_videos").text("All videos have been reviewed!");
        	  }
            });
          }
        });
    }
    $scope.update = function($event) {
    	var id = $($event.target).attr("data-id");
    	var fileNme = $($event.target).attr("data-fileNme");
    	$scope.param.entitiyJson ={};
    	$scope.param.entityJson.id = id;
    	$scope.param.entityJson.fileNme = fileNme;
    	$scope.param.entityJson.flag = "1";
    	$scope.param.entityJsonString = angular.toJson($scope.param.entityJson);
    	$.ajax({
            url: "merge",
            data: $scope.param,
            method:'POST',
            success: function() {
                $("#" + id).remove();
            }
          });	
    };
    $scope.deny = function($event) {
    	var id = $($event.target).attr("data-id")
    	var fileNme = $($event.target).attr("data-fileNme");
    	$scope.param.entityJson.id = id;
    	$scope.param.entityJson.fileNme = fileNme;
    	$scope.param.entityJsonString = angular.toJson($scope.param.entityJson);
    	$.ajax({
            url: "delete",
            data: $scope.param,
            method:'POST',
            success: function() {
            	$("#" + id).remove();
            }
          });
    }; 
	});